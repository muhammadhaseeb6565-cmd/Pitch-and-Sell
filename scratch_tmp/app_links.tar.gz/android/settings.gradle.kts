rootProject.name = "app_links"
